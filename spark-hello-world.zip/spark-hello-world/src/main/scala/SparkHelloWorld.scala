import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object SparkHelloWorld {
  def main(args: Array[String]): Unit = {    
    
    val spark = SparkSession.builder
      .appName("Spark Hello World")
      .master("local[*]")
      .config("neo4j.url", "neo4j://localhost:7687")
      .config("neo4j.authentication.basic.username", "neo4j")
      .config("neo4j.authentication.basic.password", "password")
      .config("neo4j.database", "neo4j")
      .config("spark.mongodb.read.connection.uri", "mongodb://admin:password@127.0.0.1:27017")
      .config("spark.mongodb.write.connection.uri", "mongodb://admin:password@127.0.0.1:27017")
      .getOrCreate()

    val inputFolder = "data"
    val outputFile = "filter-cve.json"

    val inputDF = spark.read.option("multiline", "true").json(inputFolder)

    println(inputDF)

    val filteredDF = inputDF
      .select(explode(col("CVE_Items")).as("item"))
      .select(
        col("item.cve.CVE_data_meta.ID").as("ID"),
        col("item.impact.baseMetricV3.cvssV3.baseScore").as("baseScore"),
        col("item.impact.baseMetricV3.cvssV3.baseSeverity").as("baseSeverity"),
        col("item.impact.baseMetricV2.exploitabilityScore").as("exploitabilityScore"),
        col("item.impact.baseMetricV2.impactScore").as("impactScore")
      )

    filteredDF.coalesce(1)
      .write
      .mode("overwrite")
      .json(outputFile)
    
    filteredDF.write
        .format("mongodb")
        .option("database", "ig-fp")
        .option("collection", "cve")
        .mode("overwrite")
        .save()

    println("Fetching limited results from MongoDB:")
    val mongoDF = spark.read
      .format("mongodb")
      .option("database", "ig-fp")
      .option("collection", "cve")
      .load()
    
    mongoDF.limit(10).show(false)

    println("mongo ok")

    filteredDF.limit(1000)
      .write
      .format("org.neo4j.spark.DataSource")
      .mode("overwrite")
      .option("labels", "CVE")
      .option("node.keys", "ID")
      .option("node.properties", "baseScore,baseSeverity,exploitabilityScore,impactScore")
      .save()

    println("Fetching limited results from Neo4j:")
    val neo4jDF = spark.read
      .format("org.neo4j.spark.DataSource")
      .option("query", "MATCH (c:CVE) RETURN c.ID AS ID, c.baseScore AS baseScore, c.baseSeverity AS baseSeverity, c.exploitabilityScore AS exploitabilityScore, c.impactScore AS impactScore")
      .load()

    neo4jDF.limit(10).show(false)

    println("neo4j ok")

    spark.stop()
  }
}
