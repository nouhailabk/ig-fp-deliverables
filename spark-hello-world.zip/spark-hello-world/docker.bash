#!/bin/bash
set -e

docker build -t spark-hello-world .

docker run --network host --rm -it -v "$(pwd):/work" -w /work spark-hello-world bash